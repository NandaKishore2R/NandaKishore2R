const mongoose = require("mongoose");
const MovieSchema = new mongoose.Schema({
  MovieTitle: { type: String, required: true },
  MovieDescription: { type: String, required: true },
  MovieReleasedate: { type: String, required: true },
  MovieStudio: { type: String, default: "Pending" },
  MovieScore: { type: Number, required: true },
});

const MovieModel = mongoose.model("movies", MovieSchema);
module.exports = MovieModel;

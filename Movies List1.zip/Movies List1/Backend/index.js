const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const MovieModel = require("./MovieSchema");

//connect to express app
const app = express();

// middlewares
app.use(express.json());
app.use(cors());

// mongoDB connection
mongoose.connect("mongodb://localhost:27017/MoviesList", {});
const database = mongoose.connection;
database.on("error", (error) => {
  console.log(error);
});
database.once("connected", () => {
  console.log("Database Connected");
});

// for fetching Movies from database
app.get("/getmovies", async (req, res) => {
  let movieCollection = await database.collection("movies");
  try {
    let movies = await movieCollection.find().toArray();
    res.status(200).send(movies);
  } catch (error) {
    console.error("Error:", error);
    res.status(404).json({ message: "Error while fetching the Movies" });
  }
});

// Adding a New Movie to the Movies collection.
app.post("/addmovie", async (req, res) => {
  let movieCollection = await database.collection("movies");
  let moviecheck = await movieCollection.findOne({
    MovieTitle: req.body.MovieTitle,
  });

  try {
    if (!moviecheck) {
      await MovieModel.create(req.body);
      res.status(201).json({ message: "New Movie added successfully..!" });
    } else {
      res.status(401).json({ message: "This movie is already available..." });
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({
      message: `Error occured while adding the movie..,\n please try again`,
    });
  }
});

//updating a movie in database
app.post("/editmovie/:name", async (req, res) => {
  try {
    const movieId = req.params.name;
    const updatedmovieData = req.body; // Assuming your request body contains the updated data
    // console.log(req.body.MovieTitle);
    // Validate and update the movie
    const updatedmovie = await MovieModel.findOneAndUpdate(
      { MovieTitle: movieId },
      { $set: updatedmovieData }, // Update specific fields using $set operator
      { new: true } // Return the updated document
    );
    console.log(updatedmovie + ` ` + movieId);

    if (updatedmovie) {
      res
        .status(200)
        .json({ message: "Movie updated successfully!", data: updatedmovie });
    } else
      return res
        .status(404)
        .json({ message: "Invalid attempt to edit the Movie" });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: `Error occured while editing the movie..,\n please try again later`,
    });
  }
});

//deleting a movie from database collection
app.delete("/delete/:name", async (req, res) => {
  try {
    const deletemovie = await MovieModel.findOneAndDelete({
      MovieTitle: req.params.name,
    });
    if (deletemovie) {
      res.status(202).json({ message: "Movie delted successfully...!" });
      console.log(req.params.MovieTitle);
    } else {
      res.status(404).json({ message: "Error while deleting the Movie..." });
    }
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(500).json({
      message: `Error occured while deleting the movie..,\n please try again later`,
    });
  }
});

app.listen(3001, () => {
  console.log(`server is running on port:3001 `);
});

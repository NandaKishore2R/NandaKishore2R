import React, { useEffect, useState } from "react";
import axios from "axios";
import "../styles/display.css";
import Movie from "./Movie";

export default function DisplayTask() {
  const [movies, setMovies] = useState([]);
  const [autofetch, setfetch] = useState(300000);

  setTimeout(() => {
    setfetch(60000);
  }, autofetch);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:3001/getmovies");
        setMovies(response.data);
      } catch (err) {
        console.log("Error while fetching tasks:", err);
      }
    };

    fetchData();
  }, [autofetch, movies]);

  return (
    <div className="Movie-view">
      <div className="task-header">
        <h3 className="p1">Title</h3>
        <h3 className="p1">Genre</h3>
        <h3 className="p1">Release date</h3>
        <h3 className="p1">Studio</h3>
        <h3 className="p1">Score</h3>
      </div>
      {movies.map((movie, index) => (
        <Movie
          key={index}
          name={movie.MovieTitle}
          Date={movie.MovieReleasedate}
          description={movie.MovieDescription}
          studio={movie.MovieStudio}
          score={movie.MovieScore}
        />
      ))}
    </div>
  );
}

import React, { useState } from "react";
import axios from "axios";
import "../styles/add.css";

export default function AddMovie() {
  const [MovieTitle, setTitle] = useState("");
  const [MovieDescription, setDescription] = useState("");
  const [MovieReleasedate, setDate] = useState("");
  const [MovieStudio, setStudio] = useState("");
  const [MovieScore, setScore] = useState("");

  async function addMovie(e) {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:3001/addmovie", {
        MovieTitle,
        MovieDescription,
        MovieReleasedate,
        MovieStudio,
        MovieScore,
      });
      if (response) {
        alert(`Movie created:${MovieTitle}`);
      }
    } catch (err) {
      console.error(err);
      alert("error while adding the Movie..!");
    }
  }

  return (
    <>
      <div className="addMovie_container">
        <form onSubmit={addMovie} className="addMovie_form">
          <input
            onChange={(e) => setTitle(e.target.value)}
            name="name"
            placeholder="Title"
            type="text"
            required
            value={MovieTitle}
          />
          <input
            onChange={(e) => setDescription(e.target.value)}
            name="description"
            placeholder="Genre"
            type="text"
            required
            value={MovieDescription}
          />
          <input
            style={{ width: "10%" }}
            onChange={(e) => setDate(e.target.value)}
            type="date"
            name="Release Date"
            required
            value={MovieReleasedate}
          />
          <input
            onChange={(e) => setStudio(e.target.value)}
            name="Studio"
            placeholder="Studio"
            value={MovieStudio}
            type="text"
            required
          />
          <input
            onChange={(e) => setScore(e.target.value)}
            name="Score"
            placeholder="Score"
            value={MovieScore}
            type="text"
            required
          />
          <button type="submit">
            <strong>Add Movie</strong>
          </button>
        </form>
      </div>
    </>
  );
}

import axios from "axios";
import React, { useState, useEffect } from "react";
import Popup from "reactjs-popup";
import "reactjs-popup/dist/index.css";

export default function MovieForm(props) {
  const [MovieTitle, setTitle] = useState(props.name);
  const [MovieDescription, setDescription] = useState(props.description);
  const [MovieReleasedate, setDate] = useState(props.date);
  const [MovieStudio, setStudio] = useState(props.studio);
  const [MovieScore, setScore] = useState(props.score);
  const id = props.name;

  useEffect(() => {
    // Set the initial values based on the props
  }, [MovieTitle, MovieDescription, MovieReleasedate, MovieStudio, MovieScore]);

  async function updateMovie(e) {
    e.preventDefault();
    try {
      const response = await axios.post(
        `http://localhost:3001/editmovie/${id}`,
        {
          MovieTitle,
          MovieDescription,
          MovieReleasedate,
          MovieStudio,
          MovieScore,
        }
      );
      if (response.status === 200) {
        alert(`Movie Updated: ${id}`);
        document.querySelector(".close").click();
      } else {
        alert("server issue");
      }
    } catch (err) {
      console.error(err);
      alert("Error while updating the Movie");
    }
  }

  return (
    <div>
      <Popup trigger={<button className="edit-btn">Edit</button>} modal nested>
        {(close) => (
          <div className="modal">
            <button className="close" id="close_popup" onClick={() => close()}>
              Close
            </button>
            <form onSubmit={updateMovie} className="updateMovie_form">
              <input
                onChange={(e) => setTitle(e.target.value)}
                name="name"
                value={MovieTitle}
                type="text"
                required
              />
              <input
                onChange={(e) => setDescription(e.target.value)}
                name="description"
                value={MovieDescription}
                type="text"
                required
              />
              <input
                style={{ width: "69%" }}
                onChange={(e) => setDate(e.target.value)}
                value={MovieReleasedate}
                type="date"
                name="dueDate"
                required
              />
              <input
                onChange={(e) => setStudio(e.target.value)}
                name="Studio"
                value={MovieStudio}
                type="text"
                required
              />
              <input
                onChange={(e) => setScore(e.target.value)}
                name="Score"
                value={MovieScore}
                type="text"
                required
              />
              <button className="update" type="submit">
                Update
              </button>
            </form>
          </div>
        )}
      </Popup>
    </div>
  );
}

import React, { useState } from "react";
import axios from "axios";
import MovieForm from "./MovieForm";
import "../styles/Movie.css";

export default function Movie(props) {
  const id = props.name;

  async function deleteTask() {
    try {
      const response = await axios.delete(`http://localhost:3001/delete/${id}`);
      if (response.status === 202) {
        console.log(`Task deleted, Name: ${id}`);
      } else {
        console.log("Error deleting the task.");
      }
    } catch (err) {
      console.error(err);
    }
  }

  return (
    <div className="element">
      <div className="task-header">
        <p className="p1">{props.name}</p>
        <p className="p1"> {props.description}</p>
        <p className="p1">{props.Date}</p>
        <p className="p1">{props.studio}</p>
        <p className="p1">{props.score}</p>
      </div>

      <div className="Task-validators">
        <MovieForm
          className="p1"
          key={props.index}
          name={props.name}
          description={props.description}
          date={props.Date}
          studio={props.studio}
          score={props.score}
        />
        <button className="delete-btn" onClick={deleteTask}>
          Delete
        </button>
      </div>
    </div>
  );
}

import React, { useState } from "react";
import AddMovie from "./AddMovie";
export default function NavComp() {
  const [addMovieForm, setForm] = useState(false);
  async function addNewMovie(e) {
    setForm(!addMovieForm);
  }
  return (
    <div style={{ height: "165px", backgroundColor: "#A9F5D0" }}>
      <nav
        style={{
          padding: "10px 20px ",
          boxSizing: "border-box",
          width: "100%",
          display: "flex",
          justifyContent: "space-between",
          position: "fixed",
          top: "0",
          left: "0",
          right: "1",
          height: "fit-content",
        }}
      >
        <h1
          style={{
            padding: "10px 20px",
            margin: "auto",
            color: "#424242",
            fontSize: "29px",
          }}
        >
          Movies List
        </h1>
        <button className="addMovieBtn" onClick={addNewMovie}>
          Add New Movie
        </button>
      </nav>
      <div className="addmovieForm">{addMovieForm && <AddMovie />}</div>
    </div>
  );
}

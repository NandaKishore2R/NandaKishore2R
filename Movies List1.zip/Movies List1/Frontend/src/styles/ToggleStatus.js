import React from "react";

export default function ToggleStatus() {
  return (
    <>
      <div>
        <input type="checkbox" className="checkbox" id="switch" />
      </div>
    </>
  );
}

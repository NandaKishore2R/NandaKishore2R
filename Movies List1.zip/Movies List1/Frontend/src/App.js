import "./App.css";
import NavComp from "./Components/NavComp";
import MovieList from "./Components/MovieList";
function App() {
  return (
    <>
      <NavComp />
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <MovieList />
        <footer
          style={{
            backgroundColor: "#A9F5D0",
            padding: "8px",
            textAlign: "center",
            position: "fixed",
            bottom: "0",
            width: "100%",
          }}
        >
          <p>&copy; 2024 My Website</p>
          <p>Designed by Name</p>
        </footer>
      </div>
    </>
  );
}

export default App;
